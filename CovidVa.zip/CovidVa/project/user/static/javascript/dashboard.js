
function showdistrict(){
    let district=document.getElementById("districtoption").style;
    let pincode=document.getElementById("pincodeoption").style;
    let districtbutton=document.getElementById("district").style;
    let pincodebutton=document.getElementById("pincode").style;
    district.display="block";
    pincode.display="none";
}
function showpincode(){
    let district=document.getElementById("districtoption").style;
    let pincode=document.getElementById("pincodeoption").style;
    let districtbutton=document.getElementById("district").style;
    let pincodebutton=document.getElementById("pincode").style;
    district.display="none";
    pincode.display="block";
}

function shownextpage(){
    let showlocation=document.getElementById("locations");
    showlocation.style.display="block";
}

function showdates() {
    let divbox = document.getElementById("date");
    let year = new Date().getFullYear();
    let month = document.getElementById("month").value;
    let date = new Date(year, month, 1);
    let dates = [];
    let i = 1;
    divbox.innerHTML = '';

    while (date.getMonth() == month) {
        dates.push(new Date(date));
        i++;
        date.setDate(date.getDate() + 1);
    }

    for (let i = 0; i < dates.length; i++) {
        let label = document.createElement('div');
        label.className = 'datesrow';

        let checkboxes = document.createElement('div');

        label.addEventListener('click', function () {
            changedata(this);
        });

        checkboxes.innerHTML += '<label for="date' + i + '">' + dates[i].getDate() + ' ' + dates[i].toLocaleString('default', { month: 'long' }) + ' ' + dates[i].getFullYear() + '</label>';

        checkboxes.innerHTML += '<input type="radio" name="date" id="date' + i + '" value="' + dates[i].getDate() + ' ' + dates[i].toLocaleString('default', { month: 'long' }) + ' ' + dates[i].getFullYear() + '">';

        label.appendChild(checkboxes);
        divbox.appendChild(label);
    }
}


function changedata(element){
    var childDivs = document.querySelectorAll(".datesrow");
    for (var i = 0; i < childDivs.length; i++) {
        childDivs[i].style.backgroundColor=" rgba(159, 136, 184, 0.296)";
        childDivs[i].style.color="black";
    }
    element.style.backgroundColor="#146C94";
    element.style.color="#FFF";
}