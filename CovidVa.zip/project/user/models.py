from django.db import models

class Slot(models.Model):
    slotid = models.AutoField(primary_key=True)
    district = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    locationname = models.CharField(max_length=200)
    vaccinetype = models.CharField(max_length=50)
    age = models.CharField(max_length=10)
    doseno = models.CharField(max_length=20)
    date = models.DateField()

    def __str__(self):
        return f"{self.slotid} - {self.locationname}"

class User(models.Model):
    userid = models.AutoField(primary_key=True)
    slot = models.ForeignKey(Slot, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    mobileno = models.CharField(max_length=15)
    gender = models.CharField(max_length=10)
    dateofbirth = models.DateField()
    district = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    villagename = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.userid} - {self.name}"
